import requests
import time
import telegram
import os

TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

bot = telegram.Bot(token=TOKEN)

def get_alerts():
    try:
        response = requests.get("https://alerts.com.ua/api/states")
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        print("Ошибка при запросе:", e)
    return None

def send_alerts():
    data = get_alerts()
    if not data:
        return
    for region in data:
        if region.get("alarm") == True:
            msg = f"🚨 Тревога в {region['name']}"
            bot.send_message(chat_id=CHAT_ID, text=msg)

if __name__ == "__main__":
    while True:
        send_alerts()
        time.sleep(300)
